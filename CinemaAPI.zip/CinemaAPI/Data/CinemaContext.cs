using Microsoft.EntityFrameworkCore;
using CinemaAPI.Models;

namespace CinemaAPI.Data
{
    public class CinemaContext : DbContext
    {
        public CinemaContext(DbContextOptions<CinemaContext> options) : base(options) {}
        public DbSet<Cinema> Cinemas { get; set; }
        public DbSet<Filme> Filmes { get; set; }
    }
}
