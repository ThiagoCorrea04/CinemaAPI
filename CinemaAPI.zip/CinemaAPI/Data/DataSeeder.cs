using CinemaAPI.Models;

namespace CinemaAPI.Data
{
    public static class DataSeeder
    {
        public static void Seed(CinemaContext context)
        {
            if (!context.Cinemas.Any())
            {
                var cinema1 = new Cinema { Nome = "Cinema 1", Cidade = "Cidade A" };
                var cinema2 = new Cinema { Nome = "Cinema 2", Cidade = "Cidade B" };
                context.Cinemas.AddRange(cinema1, cinema2);

                var filmes = new List<Filme>
                {
                    new Filme { Titulo = "Filme 1", Genero = "Ação", Duracao = 120, Cinema = cinema1 },
                    new Filme { Titulo = "Filme 2", Genero = "Comédia", Duracao = 90, Cinema = cinema1 },
                    new Filme { Titulo = "Filme 3", Genero = "Drama", Duracao = 110, Cinema = cinema1 },
                    new Filme { Titulo = "Filme 4", Genero = "Terror", Duracao = 100, Cinema = cinema2 },
                    new Filme { Titulo = "Filme 5", Genero = "Romance", Duracao = 105, Cinema = cinema2 },
                };
                context.Filmes.AddRange(filmes);
                context.SaveChanges();
            }
        }
    }
}
 