using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CinemaAPI.Models
{
    public class Cinema
    {
        [Key]
        public int Id { get; set; }

        public string? Nome { get; set; }
        public string? Cidade { get; set; } 

        public List<Filme> Filmes { get; set; } = new List<Filme>(); 
    }
}
