using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CinemaAPI.Models
{
    public class Filme
    {
        [Key]
        public int Id { get; set; }

        public string? Titulo { get; set; } 
        public string? Genero { get; set; }
        public int Duracao { get; set; }

        [ForeignKey("Cinema")]
        public int CinemaId { get; set; }
        public Cinema? Cinema { get; set; } 
    }
}
