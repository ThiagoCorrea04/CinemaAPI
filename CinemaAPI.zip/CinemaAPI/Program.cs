using CinemaAPI.Data;
using CinemaAPI.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<CinemaContext>(options =>
    options.UseSqlite("Data Source=CinemaDatabase.db"));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/cinemas", async (CinemaContext db) => await db.Cinemas.Include(c => c.Filmes).ToListAsync());
app.MapGet("/cinemas/{id}", async (int id, CinemaContext db) =>
    await db.Cinemas.Include(c => c.Filmes).FirstOrDefaultAsync(c => c.Id == id));
app.MapPost("/cinemas", async (Cinema cinema, CinemaContext db) =>
{
    db.Cinemas.Add(cinema);
    await db.SaveChangesAsync();
    return Results.Created($"/cinemas/{cinema.Id}", cinema);
});
app.MapPut("/cinemas/{id}", async (int id, Cinema updatedCinema, CinemaContext db) =>
{
    var cinema = await db.Cinemas.FindAsync(id);
    if (cinema == null) return Results.NotFound();
    cinema.Nome = updatedCinema.Nome;
    cinema.Cidade = updatedCinema.Cidade;
    await db.SaveChangesAsync();
    return Results.NoContent();
});
app.MapDelete("/cinemas/{id}", async (int id, CinemaContext db) =>
{
    var cinema = await db.Cinemas.FindAsync(id);
    if (cinema == null) return Results.NotFound();
    db.Cinemas.Remove(cinema);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<CinemaContext>();
    dbContext.Database.Migrate();
    DataSeeder.Seed(dbContext);
}

app.Run();
